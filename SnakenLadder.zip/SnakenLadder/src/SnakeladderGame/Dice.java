package SnakeladderGame;

public class Dice {

		public static int throwDice() {
			return (int) (Math.random()*6)+1; 
		}
}
