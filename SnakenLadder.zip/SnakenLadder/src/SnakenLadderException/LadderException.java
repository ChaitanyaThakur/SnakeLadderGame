package SnakenLadderException;

public class LadderException extends Exception{
public LadderException(String str) {
	super(str);
}
}
