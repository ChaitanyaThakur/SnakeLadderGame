package SnakenLadderException;

public class SnakeException extends Exception{
public SnakeException(String str) {
	super(str);
}
}
